
package com.mrgamerind.togglesprint;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ToggleSprintClient implements ClientModInitializer {

    private static KeyBinding toggleSprintKey;

    @Override
    public void onInitializeClient() {
        toggleSprintKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.togglesprint.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.togglesprint"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleSprintKey.wasPressed()) {
                ToggleSprintMod.toggleSprint = !ToggleSprintMod.toggleSprint;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("Toggle Sprint: " + (ToggleSprintMod.toggleSprint ? "ON" : "OFF")), true);
                }
            }

            if (ToggleSprintMod.toggleSprint && client.player != null && !client.player.isSneaking()) {
                client.player.setSprinting(true);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (ToggleSprintMod.toggleSprint) {
                drawContext.drawText(MinecraftClient.getInstance().textRenderer,
                        "Sprinting (Toggled)", 10, 10, 0x00FF00, true);
            }
        });
    }
}
