
package com.mrgamerind.togglesprint;

import net.fabricmc.api.ModInitializer;

public class ToggleSprintMod implements ModInitializer {
    public static boolean toggleSprint = false;

    @Override
    public void onInitialize() {
        // No initialization needed for now
    }
}
